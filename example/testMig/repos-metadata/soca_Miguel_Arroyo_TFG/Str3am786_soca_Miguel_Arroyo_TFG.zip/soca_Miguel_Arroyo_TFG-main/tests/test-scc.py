import unittest
from unittest import TestCase, mock

class test_soca(TestCase):
    pass

if __name__ == '__main__':
    unittest.main()