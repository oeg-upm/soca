# SOMEF tester

# FAQ
This is a simulation of Frequently asked Questions
Going to ask a question like this?
Sure
## General Questions
### Test Question 1?
Good spawn

### Question2?
Why not? docs.python.org

### Documentation?
It can be found in test.docs.org

## Support
More information can be found: https://github.com/Str3am786/somefTester/


